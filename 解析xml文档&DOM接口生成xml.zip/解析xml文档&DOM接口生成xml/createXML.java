import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.Entity;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.XMLWriter;

import java.io.FileOutputStream;
	//建立一个XML文档，文档名由输入属性决定

public class CreateXml {
	public static void main(String [] args) throws IOException{
	Document document = DocumentHelper.createDocument();
	Element root = document.addElement("Team");
	Element firstEle=root.addElement("TeamMember")
			.addAttribute("value","30772");
	Element name=firstEle.addElement("name")
			.addAttribute("value","Manjeet Singh");
	Element design=firstEle.addAttribute("Designation")
			.addAttribute("value","Team Leader");
	OutputFormat format=new OutputFormat(" ",ture);
	//把生成的xml文档存放在硬盘上,true代表是否换行
	format.setEncoding("UTF_8");
	XMLWriter xmlWriter=new XMLWriter(new FileOutputStream("Person.xml"),format;
	
	xmlWriter.write(document);
	xmlWriter.close();
	}
}