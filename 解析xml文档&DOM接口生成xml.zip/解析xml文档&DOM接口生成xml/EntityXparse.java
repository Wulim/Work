import java.io.*;
import java.util.*;
import org.dom4j.*;
import org.dom4j.io.*;
	//读入文件，取出文件，打印
public class EntityXparse{
	public static void main(String[]args) throws Exception{
		writeBook("C:\\Users\\fylpf\\Desktop\\src\\5.4.xml");
	}
//1.读入指定的xml文件，取出数据并打印
	private static void writeBook(String filename)throws Exception{
		//读入指定的xml文件，并构造Document对象
		File file =new File(filename);
		SAXReader reader= new SAXReader();
		//xml解析器
		try {
			Document document = DocumentHelper.createDocument();//创建新的xml文件
			Document doc = reader.read(file);					//解析器开始解析xml文件
//2.获得根元素
			Element root=doc,getRootElement();
			Element rt=document.addElement(root.getName());
//3.递归搜索子元素
            for (Iterator<Element> it = root.elementIterator(); it.hasNext();) {
                Element element = it.next();
                Element ele = rt.addElement(element.getName())
                        .addText(element.getText());			//添加到新的xml中
                System.out.println(element.getText());
            }
//把生成的xml文档存放在硬盘上，true代表是否换行
            OutputFormat format = new OutputFormat("    ",true);
            format.setEncoding("UTF-8");
            XMLWriter xmlWriter = new XMLWriter(new FileOutputStream("newXML.xml"),format);

            xmlWriter.write(document);
            xmlWriter.close();
        } catch (DocumentException e) {
            e.printStackTrace();
        }

    }
}